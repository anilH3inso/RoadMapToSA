#!/usr/bin/env bash
set -e
sudo apt-get update -y
sudo apt-get install -y curl wget net-tools dnsutils traceroute tcpdump firefox-esr
# Default route handed by DHCP; ensure DNS works (server at 10.20.20.20)
echo "[victim] ready. Try: curl http://server.lab.local, ftp 10.20.20.20"


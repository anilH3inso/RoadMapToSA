#!/usr/bin/env bash
set -e
sudo apt-get update -y
sudo apt-get install -y nmap hping3 nping mitmproxy ettercap-text-only python3-pip
pip3 install scapy
# Convenience: traffic scripts
sudo mkdir -p /opt/traffic
sudo bash -c 'cat >/opt/traffic/beacon.py' <<'PY'
#!/usr/bin/env python3
import time,requests,random
URL="http://10.20.20.20/"
UA=["curl/7.68","Mozilla/5.0","Go-http-client/1.1"]
while True:
    try:
        requests.get(URL, headers={"User-Agent": random.choice(UA)}, timeout=3)
    except Exception: pass
    time.sleep(7+random.randint(0,5))
PY
sudo chmod +x /opt/traffic/beacon.py

echo "[attacker] tools installed. Examples:"
echo "  nmap -sS -p- 10.20.20.20"
echo "  sudo hping3 -S -p 80 --flood 10.20.20.20"
echo "  python3 /opt/traffic/beacon.py"


#!/usr/bin/env bash
set -e
sudo apt-get update -y
sudo apt-get install -y tshark tcpdump ethtool
# Allow non-root capture (optional)
sudo dpkg-reconfigure -f noninteractive wireshark-common || true
sudo usermod -aG wireshark vagrant || true

# Name capture NICs (VirtualBox typically enp0s8/enp0s9)
IF_A=enp0s8
IF_B=enp0s9

# Promiscuous at OS level too (VB is set; this is belt & suspenders)
sudo ip link set $IF_A promisc on || true
sudo ip link set $IF_B promisc on || true

# Convenience capture scripts
sudo mkdir -p /opt/capture
sudo bash -c "cat >/opt/capture/cap_netA.sh" <<'SH'
#!/usr/bin/env bash
IF=enp0s8
OUT=~/netA_$(date +%F_%H%M%S).pcapng
echo "Capturing on $IF -> $OUT (Ctrl+C to stop)"
sudo tshark -i $IF -w "$OUT"
SH
sudo bash -c "cat >/opt/capture/cap_netB.sh" <<'SH'
#!/usr/bin/env bash
IF=enp0s9
OUT=~/netB_$(date +%F_%H%M%S).pcapng
echo "Capturing on $IF -> $OUT (Ctrl+C to stop)"
sudo tshark -i $IF -w "$OUT"
SH
sudo chmod +x /opt/capture/cap_*.sh

echo "[sensor] tshark ready. Use /opt/capture/cap_netA.sh or cap_netB.sh."


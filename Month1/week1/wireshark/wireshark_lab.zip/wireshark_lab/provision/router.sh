#!/usr/bin/env bash
set -e

# Enable IP forwarding
sudo sysctl -w net.ipv4.ip_forward=1
sudo sed -i 's/^#\?net.ipv4.ip_forward=.*/net.ipv4.ip_forward=1/' /etc/sysctl.conf

# Install dnsmasq + nftables
sudo apt-get update -y
sudo apt-get install -y dnsmasq nftables

# Minimal firewall between subnets (allow everything by default; easy to tweak)
sudo bash -c 'cat >/etc/nftables.conf' <<'NFT'
flush ruleset
table inet filter {
  chain input   { type filter hook input   priority 0; policy accept; }
  chain forward { type filter hook forward priority 0; policy accept; }
  chain output  { type filter hook output  priority 0; policy accept; }
}
NFT
sudo systemctl enable --now nftables

# Static IPs already assigned by Vagrant. Provide DHCP on both nets.
sudo bash -c 'cat >/etc/dnsmasq.d/lab.conf' <<'DNS'
# Subnet A (netA)
interface=enp0s8
dhcp-range=enp0s8,10.10.10.50,10.10.10.150,12h
dhcp-option=enp0s8,3,10.10.10.1
dhcp-option=enp0s8,6,10.20.20.20   # point DNS to server (bind9) once up, fallback to router if needed

# Subnet B (netB)
interface=enp0s9
dhcp-range=enp0s9,10.20.20.50,10.20.20.150,12h
dhcp-option=enp0s9,3,10.20.20.1
dhcp-option=enp0s9,6,10.20.20.20
DNS

sudo systemctl restart dnsmasq

echo "[router] ready: forwarding on, DHCP on netA/netB."


#!/usr/bin/env bash
set -e
sudo apt-get update -y
sudo apt-get install -y nginx vsftpd openssh-server bind9

# NGINX demo page
echo "Hello from ws-server (nginx) @ $(hostname) $(hostname -I)" | sudo tee /var/www/html/index.html >/dev/null
sudo systemctl enable --now nginx

# FTP: allow local, simple lab config
sudo sed -i 's/^#\?write_enable=.*/write_enable=YES/' /etc/vsftpd.conf
sudo sed -i 's/^#\?local_enable=.*/local_enable=YES/' /etc/vsftpd.conf
sudo systemctl restart vsftpd

# BIND9: simple caching + zone for lab.local
sudo bash -c 'cat >/etc/bind/named.conf.local' <<'ZNS'
zone "lab.local" {
  type master;
  file "/etc/bind/db.lab.local";
};
ZNS
sudo cp /etc/bind/db.local /etc/bind/db.lab.local
sudo sed -i 's/localhost./server.lab.local./' /etc/bind/db.lab.local
sudo sed -i 's/127.0.0.1/10.20.20.20/' /etc/bind/db.lab.local
echo "victim A 10.10.10.11"      | sudo tee -a /etc/bind/db.lab.local >/dev/null
echo "attacker A 10.10.10.13"    | sudo tee -a /etc/bind/db.lab.local >/dev/null
echo "server A 10.20.20.20"      | sudo tee -a /etc/bind/db.lab.local >/dev/null

sudo systemctl enable --now bind9
echo "[server] nginx/ftp/dns up."

